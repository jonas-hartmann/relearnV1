import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-course',
  templateUrl: 'course.html'
})
export class CoursePage {
  tab: string = "lactures";
  constructor(public navCtrl: NavController) {

  }

}
