import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { LecturerprofilePage } from '../lecturerprofile/lecturerprofile';
@Component({
  selector: 'page-courcedetails',
  templateUrl: 'courcedetails.html'
})
export class CourcedetailsPage {
  tab: string = "about";
  constructor(public navCtrl: NavController) {

  }
  
lecturerprofile() {
    this.navCtrl.push(LecturerprofilePage);
  }

}
