import { Component } from '@angular/core';
import { NavController, ViewController} from 'ionic-angular';

import { DesignPage } from '../design/design';
@Component({
  selector: 'page-search',
  templateUrl: 'search.html'
})
export class SearchPage {

  constructor(public navCtrl: NavController, public viewCtrl: ViewController) {

  }
    dismiss() {
		this.viewCtrl.dismiss();
	}
   
 design() {
    this.navCtrl.push(DesignPage);
  } 

}
