import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

 import { CourcedetailsPage } from '../courcedetails/courcedetails';
@Component({
  selector: 'page-lecturerprofile',
  templateUrl: 'lecturerprofile.html'
})
export class LecturerprofilePage {
  tab: string = "about";
  constructor(public navCtrl: NavController) {

  }
   
courcedetails() {
    this.navCtrl.push(CourcedetailsPage);
  } 

}
