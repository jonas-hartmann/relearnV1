import { Component } from '@angular/core';
import { NavController, ModalController } from 'ionic-angular';

import { DesignPage } from '../design/design';
import { SearchPage } from '../search/search';
import { CategoryPage } from '../category/category';
import { NotificationPage } from '../notification/notification';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, public modalCtrl: ModalController) {

  }
   
 search() {
    let modal = this.modalCtrl.create(SearchPage);
    modal.present();
  }
   
  design() {
    this.navCtrl.push(DesignPage);
  }   
  category() {
    this.navCtrl.push(CategoryPage);
  } 
  notification() {
    this.navCtrl.push(NotificationPage);
  } 

}
