import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { CoursePage } from '../course/course';
@Component({
  selector: 'page-ongoingcourses',
  templateUrl: 'ongoingcourses.html'
})
export class OngoingcoursesPage {

  constructor(public navCtrl: NavController) {

  }
  
  course() {
    this.navCtrl.push(CoursePage);
  }

}
