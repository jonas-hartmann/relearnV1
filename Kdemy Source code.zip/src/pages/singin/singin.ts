import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { HomePage } from '../home/home';
import { SignupPage } from '../signup/signup';
@Component({
  selector: 'page-singin',
  templateUrl: 'singin.html'
})
export class SinginPage {

  constructor(public navCtrl: NavController) {

  }
   
  home() {
    this.navCtrl.setRoot(HomePage);
  } 
  signup() {
    this.navCtrl.setRoot(SignupPage);
  }

}
