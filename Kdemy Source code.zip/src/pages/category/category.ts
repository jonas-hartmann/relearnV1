import { Component } from '@angular/core';
import { NavController, ModalController } from 'ionic-angular';

import { CourcedetailsPage } from '../courcedetails/courcedetails';
import { FiltersPage } from '../filters/filters';
@Component({
  selector: 'page-category',
  templateUrl: 'category.html'
})
export class CategoryPage {

  constructor(public navCtrl: NavController, public modalCtrl: ModalController) {

  }
  filters() {
    let modal = this.modalCtrl.create(FiltersPage);
    modal.present();
  }
 
  courcedetails() {
    this.navCtrl.push(CourcedetailsPage);
  } 

}
